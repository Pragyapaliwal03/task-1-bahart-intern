import"./header.css";


function Header(){
 return(
   <div className="header">
      <div className="headerTitles">
         <span className="headerTitleSm">React</span>
         <span className="headerTitleLg">Blog</span>
      </div>
      <img className="headerImg" src="https://www.wallpaperuse.com/wallp/0-1332_m.jpg" alt="" />
     </div>
 )
}

export default Header;
